"""QGIS Processing: install the Brush Pack style collection and create a symbol atlas.
Use Processing > Toolbox > Scripts > Add Script to Toolbox.
Requires QGIS 3.22+; intended for QGIS 3.40. No external Python packages.
"""
import json
import math
from pathlib import Path
from qgis.core import (
    QgsProcessingAlgorithm, QgsProcessingParameterFile,
    QgsProcessingParameterBoolean, QgsProcessingParameterString,
    QgsProcessingParameterFeatureSink, QgsProcessingException,
    QgsProcessingLayerPostProcessorInterface, QgsStyle, QgsFields, QgsField,
    QgsFeature, QgsGeometry, QgsPointXY, QgsCoordinateReferenceSystem,
    QgsWkbTypes, QgsFeatureSink, QgsCategorizedSymbolRenderer,
    QgsRendererCategory, QgsSymbol, QgsProperty, QgsPalLayerSettings,
    QgsTextFormat, QgsVectorLayerSimpleLabeling,
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor


class BrushPackAtlasPostProcessor(QgsProcessingLayerPostProcessorInterface):
    def __init__(self, symbol_items):
        super().__init__()
        self.symbol_items = symbol_items

    def postProcessLayer(self, layer, context, feedback):
        if not layer or not hasattr(layer, 'setRenderer'):
            return
        categories = []
        for row, symbol in self.symbol_items:
            symbol.setDataDefinedSize(QgsProperty.fromField('size_mm'))
            symbol.setDataDefinedAngle(QgsProperty.fromField('rotation'))
            categories.append(QgsRendererCategory(row['name'], symbol.clone(), row['name']))
        layer.setRenderer(QgsCategorizedSymbolRenderer('brush', categories))
        settings = QgsPalLayerSettings()
        settings.fieldName = 'brush'
        settings.enabled = True
        fmt = QgsTextFormat()
        fmt.setSize(7)
        fmt.setColor(QColor('#333333'))
        settings.setFormat(fmt)
        layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
        layer.setLabelsEnabled(True)
        layer.triggerRepaint()
        feedback.pushInfo('Atlas styled. These are artificial catalogue positions, not mapped locations.')


class BrushPackQGISProcessing(QgsProcessingAlgorithm):
    # Keeps the Python postprocessor alive until output layers have been loaded.
    _postprocessors = []

    def name(self):
        return 'brush_pack_install_and_atlas'

    def displayName(self):
        return 'Brush Pack: install symbols and create atlas'

    def group(self):
        return 'Cartography'

    def groupId(self):
        return 'cartography'

    def createInstance(self):
        return BrushPackQGISProcessing()

    def flags(self):
        # The default style database belongs to the main GUI thread.
        return super().flags() | QgsProcessingAlgorithm.FlagNoThreading

    def shortHelpString(self):
        return (
            'Select the extracted Converted_Brushes folder containing '
            'QGIS_Brush_Symbols.xml and manifest.json. Installs missing symbols '
            'without replacing existing symbols, and creates an editable point '
            'catalogue. Leave the category filter blank for all presets. '
            'The catalogue uses artificial coordinates (EPSG:3857 near 0,0); '
            'it is a visual reference, not a real map. The symbols embed their '
            'artwork, so the styled output does not depend on external image paths. '
            'Save the output to a GeoPackage, then save its style or QGIS project '
            'to retain the categorized renderer. Adjust size_mm and rotation '
            'per point. Do not copy catalogue coordinates into your real map.'
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFile(
            'PACK', 'Extracted Converted_Brushes folder',
            behavior=QgsProcessingParameterFile.Folder))
        self.addParameter(QgsProcessingParameterString(
            'FILTER', 'Category contains (optional, e.g. Mountain or Tree)',
            defaultValue='', optional=True))
        self.addParameter(QgsProcessingParameterBoolean(
            'INSTALL', 'Install missing symbols into the QGIS style library',
            defaultValue=True))
        self.addParameter(QgsProcessingParameterFeatureSink(
            'OUTPUT', 'Brush Pack symbol atlas'))

    def processAlgorithm(self, parameters, context, feedback):
        pack = Path(self.parameterAsString(parameters, 'PACK', context))
        xml_file = pack / 'QGIS_Brush_Symbols.xml'
        manifest_file = pack / 'manifest.json'
        if not xml_file.is_file() or not manifest_file.is_file():
            raise QgsProcessingException(
                'Choose the Converted_Brushes folder containing the XML and manifest.json.')
        try:
            rows = json.loads(manifest_file.read_text(encoding='utf-8'))
        except (OSError, ValueError) as exc:
            raise QgsProcessingException('Cannot read the brush index: ' + str(exc))
        pattern = self.parameterAsString(parameters, 'FILTER', context).strip().lower()
        rows = [r for r in rows if pattern in r['category'].lower()]
        if not rows:
            raise QgsProcessingException('No categories matched the filter.')
        source_style = QgsStyle()
        if not source_style.createMemoryDatabase():
            raise QgsProcessingException('Cannot create the temporary QGIS style database.')
        if not source_style.importXml(str(xml_file)):
            raise QgsProcessingException('Cannot import symbols: ' + source_style.errorString())
        symbol_items = []
        for row in rows:
            sym = source_style.symbol(row['symbol_name'])
            if sym is None:
                raise QgsProcessingException('Missing symbol: ' + row['name'])
            symbol_items.append((row, sym))
        if self.parameterAsBool(parameters, 'INSTALL', context):
            target = QgsStyle.defaultStyle()
            existing = set(target.symbolNames())
            installed = 0
            for row, sym in symbol_items:
                if feedback.isCanceled():
                    break
                name = row['symbol_name']
                if name in existing:
                    continue
                if not target.addSymbol(name, sym.clone(), True):
                    raise QgsProcessingException('Cannot save symbol: ' + name)
                target.tagSymbol(QgsStyle.SymbolEntity, name, [row['pack_name'], row['category']])
                installed += 1
            feedback.pushInfo(f'Installed {installed} symbols. Existing names were kept.')
        fields = QgsFields()
        for name, field_type in [('id', QVariant.Int), ('brush', QVariant.String),
                                 ('category', QVariant.String), ('size_mm', QVariant.Double),
                                 ('rotation', QVariant.Double)]:
            fields.append(QgsField(name, field_type))
        sink, destination = self.parameterAsSink(
            parameters, 'OUTPUT', context, fields, QgsWkbTypes.Point,
            QgsCoordinateReferenceSystem('EPSG:3857'))
        if sink is None:
            raise QgsProcessingException('Cannot create the output point layer.')
        columns = min(12, max(1, math.ceil(math.sqrt(len(rows)))))
        for i, (row, sym) in enumerate(symbol_items):
            if feedback.isCanceled():
                break
            feature = QgsFeature(fields)
            feature.setAttributes([row['id'], row['name'], row['category'], 8.0, 0.0])
            feature.setGeometry(QgsGeometry.fromPointXY(
                QgsPointXY((i % columns) * 1000.0, -(i // columns) * 1000.0)))
            if not sink.addFeature(feature, QgsFeatureSink.FastInsert):
                raise QgsProcessingException('Failed to write an atlas point.')
            feedback.setProgress((i + 1) * 100.0 / len(rows))
        if context.willLoadLayerOnCompletion(destination):
            processor = BrushPackAtlasPostProcessor(symbol_items)
            self._postprocessors.append(processor)
            context.layerToLoadOnCompletionDetails(destination).setPostProcessor(processor)
        return {'OUTPUT': destination}
