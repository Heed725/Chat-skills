#!/usr/bin/env python3
"""Convert sampled ABR 6.1/6.2, PNG or safe self-contained SVG packs to QGIS.
Dependencies: Pillow for PNG/ABR. No QGIS needed. Python 3.10+.
"""
import argparse
import base64
import collections
import csv
import hashlib
import html
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import shutil
import struct
import unicodedata
import xml.etree.ElementTree as ET
import zipfile

MAX_BYTES = 512 * 1024 * 1024
MAX_PIXELS = 50_000_000


class ConversionError(ValueError):
    pass


class Reader:
    def __init__(self, data):
        self.data = data
        self.pos = 0

    def take(self, size):
        if size < 0 or self.pos + size > len(self.data):
            raise ConversionError('Truncated binary record.')
        result = self.data[self.pos:self.pos + size]
        self.pos += size
        return result

    def number(self, fmt):
        return struct.unpack('>' + fmt, self.take(struct.calcsize('>' + fmt)))[0]

    def text(self):
        return self.take(self.number('I') * 2).decode('utf-16be').rstrip('\0')

    def key(self):
        length = self.number('I')
        return self.take(length or 4).decode('latin1')

    def descriptor(self):
        result = {'_name': self.text(), '_class': self.key()}
        count = self.number('I')
        if count > 1_000_000:
            raise ConversionError('Unreasonable descriptor item count.')
        for _ in range(count):
            key = self.key()
            result[key] = self.value(self.take(4).decode('ascii'))
        return result

    def value(self, kind):
        if kind in ('Objc', 'GlbO'):
            return self.descriptor()
        if kind == 'VlLs':
            count = self.number('I')
            if count > 1_000_000:
                raise ConversionError('Unreasonable descriptor list count.')
            return [self.value(self.take(4).decode('ascii')) for _ in range(count)]
        if kind == 'TEXT':
            return self.text()
        if kind == 'enum':
            return [self.key(), self.key()]
        if kind == 'UntF':
            return {'unit': self.take(4).decode('ascii'), 'value': self.number('d')}
        if kind == 'doub':
            return self.number('d')
        if kind == 'long':
            return self.number('i')
        if kind == 'comp':
            return self.number('q')
        if kind == 'bool':
            return bool(self.number('B'))
        if kind in ('tdta', 'alis'):
            return {'raw_hex': self.take(self.number('I')).hex()}
        raise ConversionError(f'Unsupported Photoshop descriptor type {kind!r} at byte {self.pos}.')


def pillow():
    try:
        from PIL import Image
    except ImportError as exc:
        raise ConversionError('Pillow is required for bitmap conversion.') from exc
    return Image


def slug(value):
    normalized = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode()
    return re.sub(r'[^a-zA-Z0-9_-]+', '_', normalized).strip('_') or 'Brush'


def ignored(name):
    parts = PurePosixPath(name.replace('\\', '/')).parts
    return any(p == '__MACOSX' or p == '.DS_Store' or p.startswith('._') for p in parts)


def read_inputs(path):
    if path.is_dir():
        files = sorted(p for p in path.rglob('*') if p.is_file() and not ignored(p.relative_to(path).as_posix()))
        if sum(p.stat().st_size for p in files) > MAX_BYTES:
            raise ConversionError('Input directory exceeds the 512 MiB processing limit.')
        return [(p.relative_to(path).as_posix(), p.read_bytes()) for p in files]
    if path.suffix.lower() == '.zip':
        with zipfile.ZipFile(path) as archive:
            entries = [i for i in archive.infolist() if not i.is_dir() and not ignored(i.filename)]
            if sum(i.file_size for i in entries) > MAX_BYTES:
                raise ConversionError('ZIP exceeds the 512 MiB uncompressed processing limit.')
            for entry in entries:
                if entry.filename.startswith(('/', '\\')) or '..' in PurePosixPath(entry.filename.replace('\\', '/')).parts:
                    raise ConversionError('Archive contains an unsafe path.')
            return [(i.filename, archive.read(i)) for i in entries]
    if path.stat().st_size > MAX_BYTES:
        raise ConversionError('Input exceeds the 512 MiB processing limit.')
    return [(path.name, path.read_bytes())]


def unpack_rows(data, width, height):
    reader = Reader(data)
    sizes = [reader.number('H') for _ in range(height)]
    result = bytearray()
    for size in sizes:
        row = Reader(reader.take(size))
        output = bytearray()
        while row.pos < len(row.data):
            control = row.number('B')
            if control < 128:
                output.extend(row.take(control + 1))
            elif control > 128:
                output.extend(row.take(1) * (257 - control))
            if len(output) > width:
                raise ConversionError('RLE row exceeds its declared width.')
        if len(output) != width:
            raise ConversionError('RLE row does not match its declared width.')
        result.extend(output)
    return bytes(result)


def decode_abr(data, source):
    Image = pillow()
    reader = Reader(data)
    major, minor = reader.number('H'), reader.number('H')
    if major != 6 or minor not in (1, 2):
        raise ConversionError(f'{source}: unsupported ABR version {major}.{minor}; do not silently drop this file.')
    sections = {}
    while reader.pos < len(data):
        if not any(data[reader.pos:]):
            break
        if reader.take(4) != b'8BIM':
            raise ConversionError(f'{source}: invalid ABR section signature at byte {reader.pos - 4}.')
        key = reader.take(4)
        size = reader.number('I')
        payload = reader.take(size)
        if key in (b'samp', b'desc'):
            if key in sections:
                raise ConversionError(f'{source}: repeated {key.decode()} section requires inspection.')
            sections[key] = payload
        padding = (-size) % 4
        if padding:
            reader.take(padding)
    if b'samp' not in sections or b'desc' not in sections:
        raise ConversionError(f'{source}: sampled tips or naming descriptor is missing.')
    samples = {}
    sample_reader = Reader(sections[b'samp'])
    while sample_reader.pos < len(sample_reader.data):
        length = sample_reader.number('I')
        payload = sample_reader.take(length)
        sample_reader.take((-length) % 4)
        image_reader = Reader(payload)
        uuid_len = image_reader.number('B')
        if uuid_len != 36:
            raise ConversionError(f'{source}: unexpected sample identifier length.')
        uid = image_reader.take(uuid_len).decode('ascii')
        offset = 47 if minor == 1 else 301
        image_reader.pos = offset
        top, left, bottom, right = [image_reader.number('i') for _ in range(4)]
        depth, compression = image_reader.number('H'), image_reader.number('B')
        width, height = right - left, bottom - top
        if width <= 0 or height <= 0 or width * height > MAX_PIXELS:
            raise ConversionError(f'{source}: invalid or excessive sample dimensions.')
        if depth != 8:
            raise ConversionError(f'{source}: unsupported sampled-tip depth {depth}; faithful conversion requires another decoder.')
        if compression == 0:
            pixels = image_reader.take(width * height)
        elif compression == 1:
            pixels = unpack_rows(image_reader.data[image_reader.pos:], width, height)
        else:
            raise ConversionError(f'{source}: unsupported sample compression {compression}.')
        alpha = Image.frombytes('L', (width, height), pixels)
        bbox = alpha.getbbox()
        if bbox is None:
            raise ConversionError(f'{source}: sampled tip {uid} is entirely blank.')
        alpha = alpha.crop(bbox)
        image = Image.new('RGBA', alpha.size, (0, 0, 0, 0))
        image.putalpha(alpha)
        if uid in samples:
            raise ConversionError(f'{source}: repeated sampled-tip identifier.')
        samples[uid] = image
    descriptor = Reader(sections[b'desc'])
    if descriptor.number('I') != 16:
        raise ConversionError(f'{source}: unsupported descriptor version.')
    presets = descriptor.descriptor().get('Brsh')
    if not isinstance(presets, list) or not presets:
        raise ConversionError(f'{source}: brush presets were not found.')
    output = []
    referenced = set()
    for index, preset in enumerate(presets, 1):
        tip = preset.get('Brsh', {})
        if tip.get('_class') != 'sampledBrush':
            raise ConversionError(f'{source}: non-sampled brush at preset {index}.')
        uid = tip.get('sampledData')
        if uid not in samples:
            raise ConversionError(f'{source}: missing sampled-tip reference {uid!r}.')
        name = preset.get('Nm  ') or tip.get('Nm  ') or f'Brush {index:03d}'
        image = samples[uid].copy()
        if tip.get('flipX'):
            image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        if tip.get('flipY'):
            image = image.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
        roundness = tip.get('Rndn', {'value': 100}).get('value')
        angle = tip.get('Angl', {'value': 0}).get('value')
        if roundness != 100:
            raise ConversionError(f'{source}: preset {name!r} has nondefault roundness; inspect before flattening it.')
        if not isinstance(angle, (float, int)) or not math.isfinite(angle):
            raise ConversionError(f'{source}: invalid brush angle.')
        if angle:
            image = image.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True)
            image = image.crop(image.getchannel('A').getbbox())
        referenced.add(uid)
        output.append({'original_name': name, 'category': re.sub(r'\s+\d+$', '', name.strip()) or 'Brush',
                       'image': image, 'source': source, 'source_id': uid, 'source_angle': angle})
    if referenced != set(samples):
        raise ConversionError(f'{source}: {len(set(samples) - referenced)} sampled tips have no preset; inspect before dropping them.')
    return output


def check_svg(data):
    if b'<!ENTITY' in data.upper() or b'<!DOCTYPE' in data.upper():
        raise ConversionError('SVG document types/entities require inspection before conversion.')
    root = ET.fromstring(data)
    if root.tag.split('}')[-1] != 'svg':
        raise ConversionError('Image is not an SVG document.')
    for element in root.iter():
        tag = element.tag.split('}')[-1].lower()
        if tag in ('script', 'foreignobject'):
            raise ConversionError('SVG contains active content.')
        for key, value in element.attrib.items():
            attr = key.split('}')[-1].lower()
            if attr.startswith('on'):
                raise ConversionError('SVG contains an event handler.')
            if attr == 'href' and not (value.startswith('#') or value.startswith(('data:image/png;base64,', 'data:image/jpeg;base64,'))):
                raise ConversionError('SVG depends on an external reference; embed it before conversion.')
        for text in list(element.attrib.values()) + [element.text or '']:
            if re.search(r'@import|url\(\s*[\'\"]?(?!#)[^)]', text, re.I):
                raise ConversionError('SVG contains an external CSS reference.')
    viewbox = root.get('viewBox')
    if viewbox:
        values = [float(x) for x in re.split(r'[\s,]+', viewbox.strip())]
        if len(values) != 4 or not all(math.isfinite(x) for x in values) or min(values[2:]) <= 0:
            raise ConversionError('Invalid SVG viewBox.')
        width, height = values[2:]
    else:
        def dimension(value):
            match = re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)(?:px)?', value or '')
            if not match:
                raise ConversionError('SVG needs a viewBox or numeric pixel dimensions.')
            return float(match.group(1))
        width, height = dimension(root.get('width')), dimension(root.get('height'))
    if min(width, height) <= 0:
        raise ConversionError('SVG dimensions must be positive.')
    return width, height


def decode_image(data, source, white_to_alpha):
    name = Path(source).stem
    category = Path(source).parent.name if Path(source).parent.name else 'Images'
    if Path(source).suffix.lower() == '.svg':
        width, height = check_svg(data)
        return {'original_name': name, 'category': category, 'svg_bytes': data,
                'width': width, 'height': height, 'source': source, 'source_id': hashlib.sha256(data).hexdigest()}
    Image = pillow()
    with Image.open(io.BytesIO(data)) as original:
        if original.width * original.height > MAX_PIXELS:
            raise ConversionError('Image exceeds the processing pixel limit.')
        image = original.convert('RGBA')
    if white_to_alpha:
        red, green, blue, alpha = image.split()
        if red.tobytes() != green.tobytes() or red.tobytes() != blue.tobytes():
            raise ConversionError('--white-to-alpha supports grayscale artwork only; do not remove colour blindly.')
        coverage = bytes((255 - value) * old // 255 for value, old in zip(red.tobytes(), alpha.tobytes()))
        image = Image.new('RGBA', image.size, (0, 0, 0, 0))
        image.putalpha(Image.frombytes('L', image.size, coverage))
    bbox = image.getchannel('A').getbbox()
    if bbox is None:
        raise ConversionError(f'{source}: entirely transparent image.')
    image = image.crop(bbox)
    return {'original_name': name, 'category': category, 'image': image, 'source': source,
            'source_id': hashlib.sha256(data).hexdigest()}


def add_symbol(parent, row, svg_bytes):
    symbol = ET.SubElement(parent, 'symbol', {'name': row['symbol_name'], 'type': 'marker', 'alpha': '1',
                          'clip_to_extent': '1', 'force_rhr': '0', 'tags': row['pack_name'] + ',' + row['category']})
    layer = ET.SubElement(symbol, 'layer', {'class': 'SvgMarker', 'locked': '0', 'pass': '0', 'enabled': '1'})
    properties = {'name': 'base64:' + base64.b64encode(svg_bytes).decode(), 'size': '8', 'size_unit': 'MM',
                  'angle': '0', 'offset': '0,0', 'offset_unit': 'MM', 'horizontal_anchor_point': '1',
                  'vertical_anchor_point': '1', 'fixedAspectRatio': '0', 'color': '0,0,0,255',
                  'outline_color': '0,0,0,0', 'outline_width': '0', 'outline_width_unit': 'MM', 'scale_method': 'diameter'}
    for key, value in properties.items():
        ET.SubElement(layer, 'prop', {'k': key, 'v': value})
    return symbol


def write_xml(root, path):
    ET.SubElement(root, 'colorramps')
    ET.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)


def convert(source, output, pack_name, white_to_alpha=False):
    if output.exists() and any(output.iterdir()):
        raise ConversionError('Choose a fresh output directory; existing nonempty directories are not overwritten.')
    if output.resolve() == source.resolve() or (source.is_dir() and source.resolve() in output.resolve().parents):
        raise ConversionError('Output must be separate from the input collection.')
    inputs = read_inputs(source)
    abr_files = [(n, d) for n, d in inputs if Path(n).suffix.lower() == '.abr']
    items = []
    if abr_files:
        for name, data in abr_files:
            items.extend(decode_abr(data, name))
    else:
        for name, data in inputs:
            if Path(name).suffix.lower() in ('.png', '.svg'):
                items.append(decode_image(data, name, white_to_alpha))
    if not items:
        raise ConversionError('No supported ABR, PNG or SVG artwork found. Inspect the format before extending support.')
    output.mkdir(parents=True, exist_ok=True)
    xml = ET.Element('qgis_style', {'version': '2'})
    symbols = ET.SubElement(xml, 'symbols')
    category_roots = {}
    manifest = []
    used_names = set()
    category_slugs = {}
    for index, item in enumerate(items, 1):
        original = item['original_name']
        base = original.strip() or f'Brush {index:03d}'
        name, variant = base, 1
        while name in used_names:
            variant += 1
            name = f'{base} (Variant {variant})'
        used_names.add(name)
        category = item['category'].strip() or 'Brush'
        if category not in category_slugs:
            stem = slug(category)
            suffix = 1
            category_slug = stem
            while category_slug in category_slugs.values():
                suffix += 1
                category_slug = f'{stem}_{suffix}'
            category_slugs[category] = category_slug
        stem = f'{index:04d}_{slug(name)}'
        svg_path = output / 'svg' / category_slugs[category] / (stem + '.svg')
        svg_path.parent.mkdir(parents=True, exist_ok=True)
        png_rel = ''
        if 'image' in item:
            image = item['image']
            width, height = image.size
            png_path = output / 'png' / category_slugs[category] / (stem + '.png')
            png_path.parent.mkdir(parents=True, exist_ok=True)
            image.save(png_path, optimize=True)
            png_rel = png_path.relative_to(output).as_posix()
            payload = base64.b64encode(png_path.read_bytes()).decode()
            svg_bytes = (f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
                         f'version="1.1" width="{width}" height="{height}" viewBox="0 0 {width} {height}">'
                         f'<title>{html.escape(name)}</title><image x="0" y="0" width="{width}" height="{height}" '
                         f'xlink:href="data:image/png;base64,{payload}"/></svg>').encode()
            representation = 'bitmap-backed SVG'
            artwork_hash = hashlib.sha256(struct.pack('>II', width, height) + image.tobytes()).hexdigest()
        else:
            width, height = item['width'], item['height']
            svg_bytes = item['svg_bytes']
            representation = 'original SVG'
            artwork_hash = hashlib.sha256(svg_bytes).hexdigest()
        svg_path.write_bytes(svg_bytes)
        row = {'id': index, 'name': name, 'original_name': original, 'category': category,
               'pack_name': pack_name, 'symbol_name': pack_name + ' ' + name,
               'width': width, 'height': height, 'png': png_rel,
               'svg': svg_path.relative_to(output).as_posix(), 'representation': representation,
               'source': item['source'], 'source_id': item['source_id'], 'artwork_hash': artwork_hash}
        manifest.append(row)
        symbol = add_symbol(symbols, row, svg_bytes)
        if category not in category_roots:
            category_roots[category] = ET.Element('qgis_style', {'version': '2'})
            ET.SubElement(category_roots[category], 'symbols')
        category_roots[category].find('symbols').append(ET.fromstring(ET.tostring(symbol)))
    write_xml(xml, output / 'QGIS_Brush_Symbols.xml')
    (output / 'styles_by_category').mkdir()
    for category, root in category_roots.items():
        write_xml(root, output / 'styles_by_category' / (category_slugs[category] + '.xml'))
    (output / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    with (output / 'Brush_Index.csv').open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(manifest[0]))
        writer.writeheader()
        writer.writerows(manifest)
    source_docs = []
    for number, (name, data) in enumerate(inputs, 1):
        if Path(name).suffix.lower() in ('.txt', '.md', '.html', '.rtf') or (not Path(name).suffix and re.search(r'read.?me|licen[cs]e|copying|attribution|authors?|rights|notice|copyright|permissions', Path(name).name, re.I)):
            path = output / 'source_documents' / (f'{number:04d}_' + slug(Path(name).stem) + '.txt')
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(data)
            source_docs.append({'source': name, 'file': path.relative_to(output).as_posix()})
    sections = []
    for category in category_roots:
        cards = ''.join(f'<figure data-search="{html.escape(row["name"].lower(), quote=True)}"><img loading="lazy" '
                        f'src="{row["png"] or row["svg"]}" alt="{html.escape(row["name"], quote=True)}">'
                        f'<figcaption>{html.escape(row["name"])}</figcaption></figure>'
                        for row in manifest if row['category'] == category)
        sections.append(f'<section><h2>{html.escape(category)}</h2><div class="grid">{cards}</div></section>')
    catalogue = ('<!DOCTYPE html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                 f'<title>{html.escape(pack_name)} catalogue</title><style>body{{font:16px system-ui;margin:28px;background:#faf7ef;color:#222}}'
                 '.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:12px}figure{margin:0;padding:12px;'
                 'background:white;border:1px solid #ded9cd}img{width:100%;height:120px;object-fit:contain}figcaption{font-size:13px;margin-top:12px}'
                 'header{position:sticky;top:0;background:#faf7ef;padding:12px 0}input{font:inherit;padding:10px;width:min(500px,85%)}[hidden]{display:none!important}</style>'
                 f'<header><h1>{html.escape(pack_name)}</h1><p>{len(items)} presets · {len(category_roots)} categories</p>'
                 '<input aria-label="Search symbols" type="search" placeholder="Search brush names…" oninput="filter(this.value)"></header>'
                 + ''.join(sections) + '<script>function filter(v){v=v.toLowerCase();document.querySelectorAll("figure").forEach(e=>e.hidden=!e.dataset.search.includes(v));'
                 'document.querySelectorAll("section").forEach(e=>e.hidden=![...e.querySelectorAll("figure")].some(x=>!x.hidden))}</script></html>')
    (output / 'Visual_Catalogue.html').write_text(catalogue, encoding='utf-8')
    bitmaps = [row for row in manifest if row['png']]
    if bitmaps:
        from PIL import Image, ImageDraw, ImageFont
        selected = []
        for category in category_roots:
            selected.extend([row for row in bitmaps if row['category'] == category][:4])
        cell_w, cell_h, columns = 190, 155, 6
        sheet = Image.new('RGB', (columns * cell_w, 70 + math.ceil(len(selected) / columns) * cell_h), '#faf7ef')
        draw = ImageDraw.Draw(sheet)
        try:
            font = ImageFont.truetype('DejaVuSans.ttf', 13)
        except OSError:
            font = ImageFont.load_default()
        draw.text((20, 18), pack_name + ' — representative selection', font=font, fill='#222')
        for i, row in enumerate(selected):
            x, y = i % columns * cell_w, 70 + i // columns * cell_h
            draw.rectangle((x + 5, y + 5, x + cell_w - 5, y + cell_h - 5), fill='white', outline='#ded9cd')
            image = Image.open(output / row['png'])
            image.thumbnail((cell_w - 24, cell_h - 44), Image.Resampling.LANCZOS)
            sheet.paste(image, (x + (cell_w - image.width) // 2, y + 12), image)
            draw.text((x + 12, y + cell_h - 26), row['name'][:25], font=font, fill='#222')
        sheet.save(output / 'Preview.png')
    template = Path(__file__).resolve().parents[1] / 'assets' / 'QGIS_Brush_Processing.py'
    shutil.copyfile(template, output / 'QGIS_Brush_Processing.py')
    report = {'pack_name': pack_name, 'input': str(source), 'preset_count': len(items),
              'source_tip_count': len({(row['source'], row['source_id']) for row in manifest}),
              'unique_artwork_count': len({row['artwork_hash'] for row in manifest}),
              'category_count': len(category_roots), 'abr_files': [n for n, _ in abr_files],
              'source_documents': source_docs, 'white_to_alpha': white_to_alpha,
              'bitmap_backed_count': len(bitmaps), 'original_svg_count': len(items) - len(bitmaps),
              'qgis_runtime_tested': False, 'notes': ['Static tips; Photoshop brush-engine dynamics are not transferred.',
              'Bitmap-backed SVG fill controls cannot recolour embedded artwork.',
              'PNG/SVG sidecars are ignored when ABR files are present to avoid double-converting previews.']}
    (output / 'Conversion_Report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (output / 'START_HERE.txt').write_text(
        f'{pack_name.upper()} — QGIS SYMBOL PACK\n\n{len(items)} presets in {len(category_roots)} categories.\n\n'
        'INSTALL\n1. Extract the whole ZIP.\n2. Open QGIS > Settings > Style Manager.\n'
        '3. Import/Export > Import Item(s) > QGIS_Brush_Symbols.xml.\n4. Select All and Import.\n'
        '5. Open a POINT layer > Properties > Symbology. Search the pack name and choose a symbol.\n'
        '6. Start with 5–10 mm size; adjust rotation and opacity. Save the QGIS project.\n\n'
        'BROWSE\nOpen Visual_Catalogue.html locally to search all artwork. Brush_Index.csv lists every preset.\n'
        'Use styles_by_category to import selected categories only. The XML embeds its SVG artwork.\n'
        'The svg folder also works directly with SVG Marker or layout Add Picture; bitmap inputs also produce transparent PNGs.\n\n'
        'PLACE ARTWORK ON YOUR MAP\nCreate a GeoPackage point layer in your map CRS. Toggle editing and add points\n'
        'where you want mountains, trees, buildings, etc. Apply saved symbols to that layer.\n'
        'For different artwork per point, add a brush field and use Categorized symbology.\n\n'
        'OPTIONAL QGIS PROCESSING ATLAS\nProcessing > Toolbox > Scripts > Add Script to Toolbox > QGIS_Brush_Processing.py.\n'
        'Run Brush Pack: install symbols and create atlas. Select this extracted folder.\n'
        'Leave the category filter blank for all symbols, or enter a category name. Keep output loading enabled.\n'
        'Zoom to the atlas layer, then zoom in. Edit size_mm and rotation per point if desired.\n'
        'The atlas is an artificial grid near 0,0 in EPSG:3857, not real feature locations.\n'
        'Save its output to GeoPackage, save the layer style, and save the QGIS project.\n'
        'This script keeps your existing project and named symbols.\n\n'
        'LIMITS\nBitmap inputs produce SVG containers embedding PNG artwork, not traced vectors.\n'
        'Their SVG fill controls cannot recolour pixels. Large sizes can reveal source pixel resolution.\n'
        'Original self-contained SVG inputs retain their SVG content. Check QGIS rendering for unsupported SVG features.\n'
        'Static symbols do not transfer Photoshop pressure, spacing or stroke dynamics. Dash tips are individual markers,\n'
        'not complete line styles; use a Marker Line layer to repeat them along a line.\n'
        'These decorative assets contain no geographical coordinates and do not derive terrain from a DEM.\n'
        'This is a symbol pack, not a plugin: do not use Plugins > Install from ZIP.\n\n'
        'VALIDATION AND RIGHTS\nRead Conversion_Report.json. File checks are separate from testing inside QGIS.\n'
        'QGIS runtime testing was not performed by the converter. Preserve original rights and attribution;\n'
        'read source_documents when supplied. No license is inferred when none was supplied.\n', encoding='utf-8')
    archive_path = output.with_name(output.name + '_QGIS_Importable.zip')
    if archive_path.exists():
        raise ConversionError('Output ZIP already exists; choose a different output directory.')
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for file in sorted(output.rglob('*')):
            if file.is_file():
                archive.write(file, (Path(output.name) / file.relative_to(output)).as_posix())
    return {'output': str(output.resolve()), 'zip': str(archive_path.resolve()), **report}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--name', default=None)
    parser.add_argument('--white-to-alpha', action='store_true')
    args = parser.parse_args()
    try:
        name = (args.name or args.input.stem).strip()
        if not name or any(char in name for char in '\n\r'):
            raise ConversionError('Choose a nonempty single-line pack name.')
        result = convert(args.input, args.output, name, args.white_to_alpha)
        print(json.dumps(result, ensure_ascii=False))
    except (ConversionError, OSError, zipfile.BadZipFile, ET.ParseError, UnicodeError) as exc:
        parser.exit(2, f'Conversion stopped: {exc}\n')


if __name__ == '__main__':
    main()
