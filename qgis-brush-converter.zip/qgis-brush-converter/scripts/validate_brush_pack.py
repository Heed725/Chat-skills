#!/usr/bin/env python3
"""Validate portable QGIS brush-pack files without claiming a QGIS runtime test."""
import argparse
import ast
import base64
import io
import hashlib
import struct
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile


def validate(root):
    manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    report = json.loads((root / 'Conversion_Report.json').read_text(encoding='utf-8'))
    symbols = ET.parse(root / 'QGIS_Brush_Symbols.xml').getroot().find('symbols')
    assert symbols is not None and manifest, 'Empty symbol collection.'
    assert len(manifest) == len(symbols) == report['preset_count'], 'Preset count mismatch.'
    assert len({r['name'] for r in manifest}) == len(manifest), 'Repeated display names.'
    assert len({r['symbol_name'] for r in manifest}) == len(manifest), 'Repeated style names.'
    assert len({r['svg'] for r in manifest}) == len(manifest), 'Repeated image paths.'
    assert len({(r['source'], r['source_id']) for r in manifest}) == report['source_tip_count'], 'Source-tip count mismatch.'
    assert len({r['artwork_hash'] for r in manifest}) == report['unique_artwork_count'], 'Unique artwork count mismatch.'
    assert len({r['category'] for r in manifest}) == report['category_count'], 'Category count mismatch.'
    for row, symbol in zip(manifest, symbols):
        assert symbol.get('name') == row['symbol_name'], 'Style name mismatch.'
        layer = symbol.find('layer')
        assert layer is not None and layer.get('class') == 'SvgMarker', 'Wrong symbol-layer type.'
        source = next(p.get('v') for p in layer.findall('prop') if p.get('k') == 'name')
        assert source.startswith('base64:'), 'Style has an external path.'
        data = base64.b64decode(source[7:], validate=True)
        assert data == (root / row['svg']).read_bytes(), 'Embedded SVG does not match exported SVG.'
        svg = ET.fromstring(data)
        if row['representation'] == 'bitmap-backed SVG':
            from PIL import Image
            png = (root / row['png']).read_bytes()
            with Image.open(io.BytesIO(png)) as image:
                image.load()
                assert image.mode == 'RGBA' and image.size == (row['width'], row['height']), 'PNG dimensions/transparency mismatch.'
                assert image.getchannel('A').getextrema()[1] > 0, 'Blank artwork.'
                assert hashlib.sha256(struct.pack('>II', *image.size) + image.tobytes()).hexdigest() == row['artwork_hash'], 'Bitmap artwork hash mismatch.'
            embedded_image = svg.find('{http://www.w3.org/2000/svg}image')
            assert embedded_image is not None, 'Bitmap-backed SVG has no image.'
            href = embedded_image.get('{http://www.w3.org/1999/xlink}href')
            assert href.startswith('data:image/png;base64,'), 'Artwork is not embedded PNG.'
            assert base64.b64decode(href.split(',', 1)[1], validate=True) == png, 'Embedded PNG mismatch.'
        else:
            assert row['representation'] == 'original SVG', 'Unknown image representation.'
            assert hashlib.sha256(data).hexdigest() == row['artwork_hash'], 'SVG artwork hash mismatch.'
    category_files = list((root / 'styles_by_category').glob('*.xml'))
    assert len(category_files) == report['category_count'], 'Category file count mismatch.'
    category_names = []
    for file in category_files:
        category_symbols = ET.parse(file).getroot().find('symbols')
        assert category_symbols is not None, 'Invalid category style.'
        category_names.extend(s.get('name') for s in category_symbols)
    assert len(category_names) == len(set(category_names)) == len(manifest), 'Duplicate or missing category symbols.'
    assert set(category_names) == {r['symbol_name'] for r in manifest}, 'Category membership mismatch.'
    catalogue = (root / 'Visual_Catalogue.html').read_text(encoding='utf-8')
    assert catalogue.count('<figure ') == len(manifest), 'Catalogue card count mismatch.'
    for row in manifest:
        assert (root / (row['png'] or row['svg'])).is_file(), 'Catalogue image missing.'
    for doc in report['source_documents']:
        assert (root / doc['file']).is_file(), 'Source rights document missing.'
    ast.parse((root / 'QGIS_Brush_Processing.py').read_text(encoding='utf-8'))
    assert (root / 'START_HERE.txt').is_file(), 'Installation guide missing.'
    zip_path = root.with_name(root.name + '_QGIS_Importable.zip')
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None, 'Corrupted ZIP entry.'
        expected = {str(Path(root.name) / p.relative_to(root)).replace('\\', '/') for p in root.rglob('*') if p.is_file()}
        assert set(archive.namelist()) == expected and len(archive.namelist()) == len(expected), 'ZIP content mismatch.'
        for file in root.rglob('*'):
            if file.is_file():
                name = str(Path(root.name) / file.relative_to(root)).replace('\\', '/')
                assert archive.read(name) == file.read_bytes(), 'ZIP data mismatch.'
    return {'status': 'passed', 'presets': len(manifest), 'source_tips': report['source_tip_count'], 'unique_artwork': report['unique_artwork_count'],
            'categories': report['category_count'], 'qgis_runtime_tested': report['qgis_runtime_tested']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder', type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(validate(args.folder)))
    except (AssertionError, OSError, ValueError, ET.ParseError, zipfile.BadZipFile, StopIteration) as exc:
        parser.exit(2, f'Validation failed: {exc}\n')


if __name__ == '__main__':
    main()
