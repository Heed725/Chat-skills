---
name: qgis-brush-converter
description: Convert uploaded Photoshop ABR brush packs and cartography asset ZIPs into QGIS-importable symbol collections. Use when the user asks to use brushes in QGIS, convert another brush pack, make cartographic assets QGIS importable, or invokes the brush skill. Extract brush tips, preserve names and transparency, generate embedded QGIS XML styles, PNG/SVG assets, a searchable visual catalogue, installation instructions, and an optional QGIS Processing atlas script. Support sampled ABR 6.1/6.2, PNG and self-contained SVG collections; inspect other formats before extending support.
---

# QGIS Brush Converter

## Execute the conversion

1. Inspect the attached archive or file with local tools. Reuse supplied scratch paths. Ignore macOS resource forks, `__MACOSX`, `.DS_Store` and files named `._*`. Never confuse a resource fork ending in `.abr` with the actual brush file.
2. Read any original README, license or attribution material. Preserve it in the output. Do not assume a new pack has the Ishikawa CC0 license. Do not publish the artwork beyond the user's requested output without authorization.
3. Run the bundled converter using absolute paths:

   ```bash
   python3 scripts/convert_brush_pack.py /absolute/path/upload.zip \
     --output /absolute/path/work/Converted_Brushes --name "Brush Pack"
   ```

   Resolve `scripts/` relative to this skill's actual directory. Require Pillow for bitmap inputs. Do not install QGIS merely to run the converter. Choose a fresh output directory; the converter refuses to overwrite nonempty directories. It creates a ZIP next to that directory.
4. Inspect the JSON summary and `Conversion_Report.json`. Compare `preset_count`, `source_tip_count` (distinct source references) and `unique_artwork_count` (bitmap pixel hashes or original SVG hashes). Count identical artwork once even when different source files contain it. Never reuse the Ishikawa counts for another pack. Preserve all named presets; give duplicate display names unique suffixes and unique filenames. Normalize category filenames consistently, including Unicode names and whitespace.
5. Open `Preview.png` when present and visually inspect representative symbols. Check transparency, orientation, legibility, crop bounds and duplicate variants. Open the local catalogue if needed. If an image's background appears intentional, preserve it. Use `--white-to-alpha` only when the user authorizes treating grayscale white paper as transparent; never infer this for coloured artwork.
6. Run the bundled validator:

   ```bash
   python3 scripts/validate_brush_pack.py /absolute/path/work/Converted_Brushes
   ```

   If QGIS is available, also import the XML into a temporary `QgsStyle` database and render representative symbols. Otherwise state that file checks passed and that import inside QGIS was not tested. Do not describe an XML syntax check or librsvg test as a QGIS test.
7. Read and apply the Library skill to save the newly generated user-facing ZIP. Keep skill files in their personal-skills checkout; never save the installed skill itself through Library. Do not overwrite the user's original upload.
8. Deliver the downloadable ZIP with short QGIS installation steps: **Settings → Style Manager → Import/Export → Import Item(s) → QGIS_Brush_Symbols.xml**; then apply a saved symbol to a point layer. Mention `Visual_Catalogue.html`, `START_HERE.txt` and the optional Processing script. Never instruct the user to install a symbol pack through **Plugins → Install from ZIP**.

## Preserve the correct representation

- Convert ABR sampled-tip coverage into transparent black bitmap artwork, preserving 8-bit alpha exactly. Crop only fully transparent margins. Do not invert coverage. Preserve any source brush flips and rotation; stop rather than silently ignore an unsupported roundness, sample type, pixel depth or descriptor value.
- Wrap bitmap artwork in self-contained SVG with an embedded PNG, then embed the entire SVG in the QGIS marker's `base64:` source. This prevents broken external image paths after importing styles.
- Describe bitmap-backed SVGs accurately. They preserve original resolution and ink texture but are not traced vectors; SVG fill controls do not recolour their embedded pixels. Size, rotation and opacity remain adjustable. Photoshop pressure, scattering and stroke dynamics do not transfer to static QGIS markers.
- Preserve supplied self-contained vector SVGs as vectors. Reject scripts and external references before rendering untrusted SVGs. If QGIS cannot render an SVG feature, create a faithful bitmap fallback and disclose the change. Do not use image generation to approximate a conversion.
- Keep decorative symbols distinct from geographically located layers or DEM processing. Treat the generated atlas as an artificial catalogue grid. Do not label catalogue positions as real places.

## Handle another format without guessing

Support sampled ABR major 6, minors 1 and 2 through the bundled parser. Fail clearly for unsupported ABR versions, computed brushes, malformed records, unsupported descriptor types, missing sample references or unusual pixel data. Inspect the new format and extend the decoder only with source-grounded format information and real tests. Do not silently drop failed brushes or manufacture replacement art.

Use the image route for PNG and safe self-contained SVG files, either alone or inside a ZIP. The converter does not promise direct support for Procreate `.brushset`, Photoshop `.tpl`, GIMP `.gbr` or Krita bundles. Inspect those packages, use a suitable decoder, then feed faithfully extracted PNG/SVG tips through the image route. Ask for missing files only when conversion actually requires them.

## Bundled resources

- `scripts/convert_brush_pack.py`: generic ABR and image-pack converter; emits portable QGIS styles, individual artwork, indexed categories and catalogue.
- `scripts/validate_brush_pack.py`: verifies names, counts, dimensions, embedded artwork, category collections, Processing syntax and ZIP integrity.
- `assets/QGIS_Brush_Processing.py`: template copied into each converted pack; installs missing styles and creates an editable, automatically styled point atlas. Do not claim runtime verification unless QGIS was actually available.
