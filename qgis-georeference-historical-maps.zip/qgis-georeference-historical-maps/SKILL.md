---
name: qgis-georeference-historical-maps
description: Georeference scanned historical maps, atlas plates, and geological quarter-degree sheets in QGIS. Use when a user attaches a map and asks to georeference it, make a QGIS project, or do the same as a previous historical-map package. Preserve the full scan and deliver a portable QGZ, lossless GeoTIFF, editable control points, and original-sheet print layout.
---

# Georeference historical maps in QGIS

## Establish the source and grid

- Read the supplied scan at native resolution. Use the local attachment copy when provided. Record the printed title, sheet number, date, scale, projection and source credit. Check archival records for unclear details.
- Inspect enlarged crops of the graticule and labels. Keep the legend, insets, margins, folds and binding visible in the full-sheet deliverable. Georeference the main map. Independently register an inset only when requested and when sufficient controls exist.
- Measure unambiguous grid intersections spread across the mapped area. For rectangular quarter-degree sheets, prefer the four inner map-frame corners and the two 10-minute ticks on each side when present. Transfer the tick positions onto the inner neatline. Use longitude first and negative latitude for south. Omit ambiguous crossings and record genuine discontinuities such as scan folds.
- Identify the longitude origin before assigning values. When Paris and Greenwich scales coexist, establish which matches the full meridians. For Paris-based controls add 2.3372291667 degrees to the signed Paris longitude to express it relative to Greenwich.

## Fit the registration

- Prefer the printed projection and known datum. For regional or continental plates, compare plausible projections and, where needed, fit reasonable parameters against distributed grid crossings. Candidate types include azimuthal equidistant, Lambert azimuthal equal area, sinusoidal and conformal conic. A polar grid needs its printed orientation as well as the pole and radial spacing. Check a few clearly identifiable tick positions or crossings outside the fit.
- For small Tanzanian geological sheets compatible with the Monduli, Ngorongoro and Gelai–Ketumbeine series, use Arc 1960 (EPSG:4210) as a working assumption where the historical datum cannot be confirmed. Prefer verified datum evidence when available. For a historic atlas with a fitted projection, document the working ellipsoid or sphere and the inferred parameters.
- Prefer a first-order affine fit in the appropriate map CRS when the residuals and map-wide alignment support it. Preserve decoded scan pixels by embedding the GeoTIFF geotransform without warping. Investigate large or patterned residuals using the source crops and holdout controls. If genuine scan distortion requires a warp, preserve the original JPEG and use it for the layout, document the warp and check that the full intended coverage survives.
- Report RMS in source pixels against the measured marks. Keep historical datum uncertainty and any independent modern basemap checks explicit. A grid-fit residual measures agreement with the printed graticule.

## Build and verify

Use [scripts/build_affine_project.py](scripts/build_affine_project.py) after choosing the fit. Run it with the Python interpreter that imports PyQGIS, GDAL, and NumPy. Use an offscreen QGIS session when headless. Supply a CSV with the exact header `pixel_x,pixel_y,map_x,map_y`. Use zero-based pixel-centre indices measured from the top-left for the first two columns. Supply final CRS coordinates for the last two, in x/y order (longitude/latitude for a geographic CRS). Convert lon/lat through PyProj or QGIS before writing a projected target CSV. For projected coordinates, use the same projection definition and parameters in the CSV and the script.

```bash
QT_QPA_PLATFORM=offscreen /usr/bin/python3 scripts/build_affine_project.py scan.jpg controls.csv Map_Name_QGIS.zip \
  --name Map_Name --title 'Original map title (year)' --crs 'EPSG:4210' \
  --notes 'Arc 1960 is a working assumption. Original datum unconfirmed.'
```

Pass `--source` for provenance and `--page-width-mm` when a printed scale bar or archive record supports a page width. Derive the scanned page width from a bar when possible. A distance of D kilometres at scale 1:N represents D × 1,000,000 / N millimetres. Multiply that by the ratio of the full scan width to the measured bar width. The optional page width preserves aspect ratio. The helper prints the fit residuals and checks that the ZIP opens after extraction elsewhere, the GeoTIFF pixels match the original, and the layout resolves the bundled scan and renders.

Check the fit is reasonable for the source before delivering the ZIP. Save the verified ZIP using the available persistent-file workflow. Give the project filename, **Project → Layouts → Original map sheet**, fit RMS and relevant assumptions. Keep source credits and a short opening guide inside the ZIP.
