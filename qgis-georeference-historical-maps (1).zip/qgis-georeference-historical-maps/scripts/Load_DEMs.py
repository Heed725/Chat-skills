"""Load selected DEMs into the named frames of the project's Original map sheet."""
from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox
from qgis.core import QgsCoordinateTransform, QgsLayoutItemMap, QgsProject, QgsRasterLayer
from qgis.utils import iface


def apply_dem(project, frame, path):
    name = frame.id().removeprefix("DEM: ")
    layer = QgsRasterLayer(path, f"{name} DEM")
    if not layer.isValid() or not layer.crs().isValid():
        raise ValueError("Choose a raster with a valid source CRS.")
    transform = QgsCoordinateTransform(layer.crs(), frame.crs(), project)
    if not transform.isValid() or not transform.transformBoundingBox(layer.extent()).intersects(frame.extent()):
        raise ValueError(f"The raster extent does not overlap the {name} frame.")
    layer.renderer().setOpacity(0.48)
    previous = [old.id() for old in frame.layers() if old.customProperty("original_sheet/dem") == name]
    layer.setCustomProperty("original_sheet/dem", name)
    project.addMapLayer(layer)
    project.layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(False)
    frame.setLayers([layer])
    frame.setItemOpacity(1)
    frame.refresh()
    project.removeMapLayers(previous)
    project.setDirty(True)
    return layer


def run():
    project = QgsProject.instance()
    layout = project.layoutManager().layoutByName("Original map sheet")
    frames = sorted(
        (item for item in layout.items()
         if isinstance(item, QgsLayoutItemMap) and item.id().startswith("DEM: ")),
        key=lambda item: item.customProperty("original_sheet/order", 0),
    ) if layout else []
    if not frames:
        QMessageBox.warning(iface.mainWindow(), "Load DEMs", "Open a project with Original map sheet DEM frames.")
        return
    for frame in frames:
        name = frame.id().removeprefix("DEM: ")
        path, _ = QFileDialog.getOpenFileName(
            iface.mainWindow(), f"Select the DEM for {name} (Cancel to skip)",
            project.homePath(), "Raster files (*.tif *.tiff *.img *.vrt *.nc *.asc);;All files (*)",
        )
        if path:
            try:
                apply_dem(project, frame, path)
            except Exception as error:
                QMessageBox.warning(iface.mainWindow(), "Load DEMs", str(error))
    iface.openLayoutDesigner(layout)


if __name__ == "__main__":
    run()
