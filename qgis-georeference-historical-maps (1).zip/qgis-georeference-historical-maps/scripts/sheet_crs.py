"""Align affine scan axes while retaining a geographic transform."""
import numpy as np
from qgis.core import Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY, QgsRectangle


def upright_crs(base, affine, name):
    """Use a derived projected CRS with square scan pixels (affine rows: origin, column, row)."""
    wkt = base.toWkt(Qgis.CrsWktVariant.Wkt2_2019)
    if not wkt.startswith("PROJCRS["):
        raise ValueError("Upright display needs a projected base CRS.")
    matrix = affine[1:].T
    scale = np.sqrt(abs(np.linalg.det(matrix)))
    undo = np.diag([scale, -scale]) @ np.linalg.inv(matrix)
    length, coefficient = 'LENGTHUNIT["metre",1]', 'SCALEUNIT["coefficient",1]'
    parameters = [
        ("A0", 0, length, 8623), ("A1", undo[0, 0], coefficient, 8624),
        ("A2", undo[0, 1], coefficient, 8625), ("B0", 0, length, 8639),
        ("B1", undo[1, 0], coefficient, 8640), ("B2", undo[1, 1], coefficient, 8641),
    ]
    conversion = 'DERIVINGCONVERSION["Scan axes",METHOD["Affine parametric transformation",ID["EPSG",9624]],'
    conversion += ",".join(f'PARAMETER["{k}",{v:.17g},{u},ID["EPSG",{c}]]' for k, v, u, c in parameters) + "]"
    axes = f'CS[Cartesian,2],AXIS["easting",east,ORDER[1],{length}],AXIS["northing",north,ORDER[2],{length}]'
    crs = QgsCoordinateReferenceSystem.fromWkt(f'DERIVEDPROJCRS["{name}",BASE{wkt},{conversion},{axes}]')
    if not crs.isValid():
        raise ValueError("QGIS could not create the upright display CRS.")
    return crs


def sheet_extent(base, display, affine, width, height, project):
    transform = QgsCoordinateTransform(base, display, project)
    to_geographic = QgsCoordinateReferenceSystem("EPSG:4326")
    direct = QgsCoordinateTransform(base, to_geographic, project)
    via = QgsCoordinateTransform(display, to_geographic, project)
    result = []
    for x, y in [(0, 0), (width, 0), (0, height), (width, height)]:
        source = QgsPointXY(*(np.array([1, x, y]) @ affine))
        p = transform.transform(source)
        if direct.transform(source).distance(via.transform(p)) > 1e-7:
            raise ValueError("The upright CRS changed geographic coordinates.")
        result.append(p)
    tl, tr, bl, br = result
    if max(abs(tl.y()-tr.y()), abs(tl.x()-bl.x()), abs(bl.y()-br.y()), abs(tr.x()-br.x())) > 1e-5:
        raise ValueError("The upright CRS did not align to the scan axes.")
    return QgsRectangle(tl.x(), bl.y(), tr.x(), tl.y())
