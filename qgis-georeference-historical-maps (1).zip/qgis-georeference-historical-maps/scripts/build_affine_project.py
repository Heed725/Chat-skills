#!/usr/bin/env python3
"""Build and verify a portable QGIS package from measured map controls."""
import argparse
import csv
from pathlib import Path
import re
import shutil
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
from osgeo import gdal

from qgis.PyQt.QtCore import QSize, Qt
from qgis.core import (
    Qgis, QgsApplication, QgsCoordinateReferenceSystem, QgsLayoutExporter,
    QgsLayoutItemPicture, QgsLayoutPoint, QgsLayoutSize, QgsPrintLayout,
    QgsProject, QgsRasterLayer, QgsReferencedRectangle,
)


from sheet_crs import sheet_extent, upright_crs


def read_controls(path, width, height):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        columns = ("pixel_x", "pixel_y", "map_x", "map_y")
        if tuple(reader.fieldnames or ()) != columns:
            raise ValueError(f"Controls CSV needs columns {', '.join(columns)}")
        values = np.array([[float(row[col]) for col in columns] for row in reader])
    if len(values) < 3 or not np.isfinite(values).all():
        raise ValueError("Provide at least three finite control points")
    source, target = values[:, :2], values[:, 2:]
    if np.any(source < 0) or np.any(source > np.array([width - 1, height - 1])):
        raise ValueError("Control pixel-centre indices must be within the scan")
    if len(np.unique(source, axis=0)) != len(source):
        raise ValueError("Control source pixels must be distinct")
    pixels = source + 0.5
    design = np.column_stack((np.ones(len(pixels)), pixels))
    affine, _, rank, _ = np.linalg.lstsq(design, target, rcond=None)
    if rank != 3 or np.linalg.matrix_rank(affine[1:]) != 2:
        raise ValueError("Controls must support an invertible affine transform")
    errors = (target - affine[0]) @ np.linalg.inv(affine[1:]) - pixels
    return pixels, target, affine, errors


def build(root, args):
    data = root / "map"
    data.mkdir(parents=True)
    original = data / ("Original_scan" + args.image.suffix.lower())
    shutil.copyfile(args.image, original)
    image = gdal.Open(str(original))
    width, height = image.RasterXSize, image.RasterYSize
    pixels, targets, affine, errors = read_controls(args.controls, width, height)
    residuals = np.linalg.norm(errors, axis=1)
    rms = np.sqrt(np.mean(residuals**2))
    crs = QgsCoordinateReferenceSystem(args.crs)
    if args.crs.lstrip().startswith("+proj="):
        crs = QgsCoordinateReferenceSystem.fromProj(args.crs)
    if not crs.isValid():
        raise ValueError("Supply a valid QGIS CRS definition")
    raster_path = data / "Georeferenced.tif"
    raster = gdal.GetDriverByName("GTiff").CreateCopy(
        str(raster_path), image, options=["TILED=YES", "COMPRESS=DEFLATE"]
    )
    raster.SetProjection(crs.toWkt())
    raster.SetGeoTransform(tuple(affine[:, 0]) + tuple(affine[:, 1]))
    raster.SetMetadataItem("TIFFTAG_IMAGEDESCRIPTION", args.title)
    raster = None
    image = None

    with Path(str(original) + ".points").open("w", newline="", encoding="utf-8") as stream:
        stream.write(f"#CRS: {crs.toWkt()}\n")
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(("mapX", "mapY", "sourceX", "sourceY", "enable", "dX", "dY", "residual"))
        for (mx, my), (x, y), (dx, dy), r in zip(targets, pixels, errors, residuals):
            writer.writerow((f"{mx:.12g}", f"{my:.12g}", f"{x:.4f}", f"{-y:.4f}", 1,
                             f"{dx:.4f}", f"{-dy:.4f}", f"{r:.4f}"))

    project = QgsProject.instance()
    project.setFileName(str(root / f"{args.name}.qgz"))
    project.setFilePathStorage(Qgis.FilePathType.Relative)
    project.setTitle(args.title)
    display = upright_crs(crs, affine, args.name) if args.upright else crs
    project.setCrs(display)
    layer = QgsRasterLayer(str(raster_path), args.title)
    if not layer.isValid() or not layer.crs().isValid():
        raise ValueError("QGIS could not load the GeoTIFF with its CRS")
    metadata = layer.metadata()
    metadata.setTitle(args.title)
    metadata.setIdentifier(args.source)
    metadata.setAbstract(args.notes)
    layer.setMetadata(metadata)
    project.addMapLayer(layer)
    extent = sheet_extent(crs, display, affine, width, height, project) if args.upright else layer.extent()
    project.viewSettings().setDefaultViewExtent(QgsReferencedRectangle(extent, display))

    page_width = args.page_width_mm if args.page_width_mm is not None else 297
    page_height = page_width * height / width
    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.setName("Original map sheet")
    layout.pageCollection().pages()[0].setPageSize(QgsLayoutSize(page_width, page_height))
    layout.renderContext().setDpi(150)
    picture = QgsLayoutItemPicture(layout)
    picture.setId("Original scan")
    layout.addLayoutItem(picture)
    picture.attemptMove(QgsLayoutPoint(0, 0))
    picture.attemptResize(QgsLayoutSize(page_width, page_height))
    picture.setResizeMode(QgsLayoutItemPicture.Zoom)
    picture.setPicturePath(str(original), Qgis.PictureFormat.Raster)
    project.layoutManager().addLayout(layout)
    if not project.write():
        raise RuntimeError("Could not write the QGIS project")
    project.clear()

    page_basis = ("Width supplied for this sheet." if args.page_width_mm is not None
                  else "Width chosen for convenient printing.")
    display_note = ("The project uses a separate upright display CRS. The GeoTIFF retains its geographic registration.\n"
                    if args.upright else "")
    (root / "README.txt").write_text(
        f"{args.title}\n{args.source}\n\n"
        f"Extract the ZIP and open {args.name}.qgz.\n"
        "Use Project > Layouts > Original map sheet to print or export the full scan.\n"
        f"Layout size {page_width:.1f} × {page_height:.1f} mm. {page_basis}\n\n"
        + display_note + f"Source scan {args.image.name}, {width} × {height} pixels.\n"
        f"Affine fit from {len(pixels)} controls in {crs.description() or args.crs}.\n"
        f"Fit to the supplied control points was {rms:.2f} source pixels RMS "
        f"(maximum {residuals.max():.2f}).\n{args.notes}\n\n"
        f"To edit registration, open map/{original.name} in QGIS Georeferencer "
        "and load its adjacent .points file.\n",
        encoding="utf-8",
    )
    return original.name, len(pixels), rms, residuals.max()


def verify(archive_path, name, scan_name, point_count):
    with TemporaryDirectory() as extracted, ZipFile(archive_path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("The ZIP integrity check failed")
        archive.extractall(extracted)
        root = Path(extracted) / name
        project = QgsProject.instance()
        try:
            assert project.read(str(root / f"{name}.qgz")) and project.crs().isValid()
            layer, = project.mapLayers().values()
            assert layer.isValid() and layer.crs().isValid()
            raster = root / "map" / "Georeferenced.tif"
            assert Path(layer.source()) == raster
            scan = root / "map" / scan_name
            raw = gdal.Open(str(scan))
            georeferenced = gdal.Open(str(raster))
            for row in range(0, raw.RasterYSize, 256):
                size = min(256, raw.RasterYSize - row)
                assert np.array_equal(
                    raw.ReadAsArray(0, row, raw.RasterXSize, size),
                    georeferenced.ReadAsArray(0, row, raw.RasterXSize, size),
                )
            if project.crs() != layer.crs():
                affine = np.asarray(georeferenced.GetGeoTransform()).reshape(2, 3).T
                sheet_extent(layer.crs(), project.crs(), affine, raw.RasterXSize, raw.RasterYSize, project)
            assert len(Path(str(scan) + ".points").read_text().splitlines()) == point_count + 2
            layout = project.layoutManager().layoutByName("Original map sheet")
            item = layout.itemById("Original scan")
            assert Path(item.picturePath()) == scan and not item.isMissingImage()
            size = QSize(raw.RasterXSize, raw.RasterYSize).scaled(1000, 1000, Qt.KeepAspectRatio)
            image = QgsLayoutExporter(layout).renderPageToImage(0, size)
            assert not image.isNull()
        finally:
            project.clear()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("image", type=Path)
    parser.add_argument("controls", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--crs", required=True, help="QGIS CRS identifier or definition")
    parser.add_argument("--source", default="", help="Source credit or link")
    parser.add_argument("--notes", default="", help="Projection, datum and other fit notes")
    parser.add_argument("--page-width-mm", type=float)
    parser.add_argument("--upright", action="store_true", help="Align the canvas to the scan axes using a derived projected CRS")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", args.name):
        parser.error("--name must contain only ASCII letters, digits, underscores or hyphens")
    if args.page_width_mm is not None and (not np.isfinite(args.page_width_mm) or args.page_width_mm <= 0):
        parser.error("--page-width-mm must be positive and finite")
    if args.output.suffix.lower() != ".zip":
        parser.error("Output file must end in .zip")
    args.output = args.output.resolve()
    if args.output.exists():
        parser.error("Choose an unused output ZIP path")
    gdal.UseExceptions()
    app = QgsApplication([], False)
    app.initQgis()
    with TemporaryDirectory() as staging:
        root = Path(staging).resolve() / args.name
        scan_name, count, rms, maximum = build(root, args)
        candidate = root.parent / "project.zip"
        with ZipFile(candidate, "w", ZIP_DEFLATED) as archive:
            for file in sorted(root.rglob("*")):
                if file.is_file():
                    archive.write(file, file.relative_to(root.parent))
        verify(candidate, args.name, scan_name, count)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with candidate.open("rb") as source, args.output.open("xb") as output:
            shutil.copyfileobj(source, output)
    print(f"Verified {args.output}\n{count} controls • {rms:.2f} px RMS • {maximum:.2f} px maximum")


if __name__ == "__main__":
    main()
