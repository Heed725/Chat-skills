"""Add independently registered DEM panels to a full-page Original map sheet layout."""
import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from osgeo import gdal
from qgis.PyQt.QtCore import QPointF
from qgis.PyQt.QtGui import QPolygonF
from qgis.core import (
    QgsApplication, QgsCoordinateReferenceSystem, QgsFillSymbol, QgsLayoutItemMap,
    QgsLayoutItemPolygon, QgsLayoutPoint, QgsLayoutSize, QgsProject,
)

from build_affine_project import read_controls
from sheet_crs import sheet_extent, upright_crs


def add_frame(layout, project, panel, controls_path, width, height, order):
    name = panel["name"]
    if not name.strip() or layout.itemById(f"DEM: {name}"):
        raise ValueError(f"Choose a unique panel name: {name!r}")
    base = QgsCoordinateReferenceSystem(panel["crs"])
    if panel["crs"].startswith("+proj="):
        base = QgsCoordinateReferenceSystem.fromProj(panel["crs"])
    _, _, affine, errors = read_controls(controls_path, width, height)
    display = upright_crs(base, affine, f"{name} sheet axes")
    extent = sheet_extent(base, display, affine, width, height, project)
    if layout.pageCollection().pageCount() != 1:
        raise ValueError("The original sheet layout must have one full-page scan.")
    page = layout.pageCollection().pages()[0].pageSize()
    if not np.isclose(page.width()/page.height(), width/height, rtol=1e-5):
        raise ValueError("The page and source scan must have matching aspect ratios.")
    vertices = np.asarray(panel["clip"], dtype=float)
    if (vertices.ndim != 2 or vertices.shape[1] != 2 or len(vertices) < 3
            or not np.isfinite(vertices).all() or np.any(vertices < 0)
            or np.any(vertices > np.array([width, height]))):
        raise ValueError(f"Invalid clipping polygon for {name}.")
    points = [QPointF(x * page.width()/width, y * page.height()/height) for x, y in vertices]
    clip = QgsLayoutItemPolygon(QPolygonF(points), layout)
    clip.setId(f"Clip: {name}")
    clip.setSymbol(QgsFillSymbol.createSimple({"style": "no", "outline_style": "no"}))
    layout.addLayoutItem(clip)
    frame = QgsLayoutItemMap(layout)
    frame.setId(f"DEM: {name}")
    frame.setCustomProperty("original_sheet/order", order)
    layout.addLayoutItem(frame)
    frame.attemptMove(QgsLayoutPoint(0, 0))
    frame.attemptResize(QgsLayoutSize(page.width(), page.height()))
    frame.setCrs(display)
    frame.zoomToExtent(extent)
    frame.setBackgroundEnabled(False)
    frame.setKeepLayerSet(True)
    frame.setLayers([])
    frame.itemClippingSettings().setSourceItem(clip)
    frame.itemClippingSettings().setEnabled(True)
    frame.setItemOpacity(0)
    print(f"{name}: {np.sqrt(np.mean(np.sum(errors**2, axis=1))):.2f} source pixels RMS")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path, help="Extracted QGZ file")
    parser.add_argument("scan", type=Path, help="Exact scan displayed on the whole layout page")
    parser.add_argument("panels", type=Path, help="Panel JSON and relative paths to its control CSVs")
    args = parser.parse_args()
    app = QgsApplication([], False)
    app.initQgis()
    gdal.UseExceptions()
    project = QgsProject.instance()
    if not project.read(str(args.project.resolve())):
        raise ValueError("The project could not be opened.")
    layout = project.layoutManager().layoutByName("Original map sheet")
    if layout is None:
        raise ValueError("The project needs an Original map sheet layout.")
    scan = gdal.Open(str(args.scan))
    panels = json.loads(args.panels.read_text(encoding="utf-8"))
    for order, panel in enumerate(panels):
        add_frame(layout, project, panel, args.panels.parent / panel["controls"],
                  scan.RasterXSize, scan.RasterYSize, order)
    if not project.write():
        raise RuntimeError("QGIS could not save the project.")
    shutil.copyfile(Path(__file__).with_name("Load_DEMs.py"), args.project.parent / "Load_DEMs.py")
    project.clear()


if __name__ == "__main__":
    main()
