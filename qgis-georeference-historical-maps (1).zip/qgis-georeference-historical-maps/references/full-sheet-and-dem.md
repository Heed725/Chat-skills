# Full-sheet scans and DEM overlays

## Recover archival detail

- Prefer a verified higher-resolution copy of the identical archival scan. For IIIF, read the item's image-service info.json and respect the advertised size, tile and area limits. Validate the complete download by decoding it.
- Transfer control coordinates only after confirming the pixel-to-pixel relationship. Match regions spread across the entire sheet, including opposite edges. Fit a scale or affine transform between scan pixels and check independent regions. Measure new controls if the archive copy is a different scan or has a different crop or distortion.
- Keep the original raster geometry and decoded color values. Use a losslessly compressed GeoTIFF, or a GeoTIFF made by verified direct JPEG transfer. Compare decoded source and GeoTIFF pixels in strips. For smaller downloads, consider a portable VRT with bundled original JPEG tiles and losslessly compressed masks. Verify equal visible pixels and test after extracting elsewhere. Report genuine source resolution and cite the archive in the project README.

## Keep the sheet upright

- For a projected base CRS in metres, pass `--upright` to the affine builder. It uses a derived projected display CRS that aligns the scan axes while retaining the GeoTIFF's fitted geographic registration. Check all four corners and coordinate agreement before and after saving. Leave the ordinary display CRS for geographic base CRSs or when the software lacks the required derived CRS support.
- If the sheet has several independent maps, georeference each in its own CRS and preserve the complete sheet as one picture. Keep the primary project view focused on the original sheet or on the main geographic map according to the request. A paper-coordinate overview is appropriate when the panels cannot share one geographic canvas, such as facing polar maps.
- For polar panels, identify the printed pole, longitude orientation, and parallel radii. Compare polar azimuthal equidistant, stereographic and Lambert azimuthal equal-area fits. Test the actual intended DEM CRSs where available, for example EPSG:3413 and EPSG:3031. Historical ice and coastlines may differ from modern data.

## Add DEM frames to the original layout

1. Prepare one control CSV per panel, using the same header and pixel-centre convention as the affine builder. Fit each panel independently from its own printed grid. Use coordinates measured on the *full-resolution full-sheet image used in the layout*, even for a small inset. Use a projected CRS in metres and convert the measured longitude and latitude targets into that CRS. Keep each panel's controls and fit statistics in the delivered bundle.
2. Extract the project ZIP to a staging directory. The layout `Original map sheet` must be one page with the archival scan filling that page at its original aspect ratio. Prepare JSON listing panels in the order the loader should offer them.

```json
[
  {
    "name": "Main map",
    "crs": "+proj=sinu +lon_0=22 +datum=WGS84 +units=m +no_defs +type=crs",
    "controls": "main_controls.csv",
    "clip": [[40, 40], [1800, 40], [1800, 1950], [740, 1950], [740, 1220], [40, 1220]]
  }
]
```

Use the example only as a schema. Choose the projection, panel name, and vertices per sheet. Clip vertices are pixel-edge coordinates on the full-sheet scan, increasing east across the image and down from its top edge. Trace the panel neatline and exclude legends and other panels. Approximate circular boundaries with distributed vertices. Keep the base image visible beneath the overlay.

3. Run the bundled builder, adapting paths as needed:

```bash
QT_QPA_PLATFORM=offscreen /usr/bin/python3 scripts/add_dem_frames.py extracted/Map.qgz extracted/map/Original_scan.jpg panels.json
```

4. Reopen the QGZ. Verify independent panel positions with the actual DEMs or with a synthetic marked raster whose geographic locations are known. Check clipping and that legends and inset borders remain visible. Save and reopen again to verify frame references. Package the project, scan, control files and `Load_DEMs.py` beside the QGZ. Keep all project data paths relative. Recheck extracted ZIP integrity, layer resolution and layout rendering.
5. Tell the user to open the project and run the following in **Plugins → Python Console**. The loader asks for each panel's DEM, opens the original layout, and lets the user choose the same correctly referenced DEM more than once. Cancel skips a panel. Save the QGZ to keep the selections. The DEM files must remain available at their referenced paths.

```python
exec(open(QgsProject.instance().homePath() + "/Load_DEMs.py", encoding="utf-8").read(), {"__name__": "__main__"})
```
