# QGIS Plugin Acceptance Checklist

## Package and metadata

- The ZIP has exactly one top-level Python package directory.
- The directory starts with a letter or underscore and contains only letters,
  digits and underscores.
- `__init__.py` and `metadata.txt` are directly under that directory.
- Required metadata is non-empty: `name`, `description`, `version`,
  `qgisMinimumVersion`, `author`, `email`, `repository`, and `tracker`.
- Prefer `qgisMaximumVersion=4.99` only when the code has been reviewed for
  QGIS 4; otherwise declare the verified maximum honestly.
- Set `hasProcessingProvider=yes` only when the plugin registers one.
- Include `server=False`, `experimental=False`, and `deprecated=False` when true.

## Qt6 and QGIS 4 review

Use the current scoped form and retain a fallback only when supporting older
QGIS/Qt. Avoid leaving the legacy attribute in executable dotted syntax because
the official checker still flags it.

Common migrations include:

| Legacy form | Scoped direction |
| --- | --- |
| `Qgis.Warning` | `Qgis.MessageLevel.Warning` |
| `Qt.DisplayRole` | `Qt.ItemDataRole.DisplayRole` |
| `Qt.AlignCenter` | `Qt.AlignmentFlag.AlignCenter` |
| `Qt.NoPen` | `Qt.PenStyle.NoPen` |
| `QColor.HexRgb` | `QColor.NameFormat.HexRgb` |
| `QImage.Format_ARGB32` | `QImage.Format.Format_ARGB32` |
| `QgsProcessing.TypeVectorPoint` | `QgsProcessing.SourceType.TypeVectorPoint` |
| `QgsFeatureSink.FastInsert` | `QgsFeatureSink.Flag.FastInsert` |
| `QgsProcessingAlgorithm.FlagNoThreading` | `Qgis.ProcessingAlgorithmFlag.NoThreading` |
| `QgsProcessingParameterNumber.Integer` | `Qgis.ProcessingNumberParameterType.Integer` |
| `QgsLayoutItemPicture.Zoom` | `QgsLayoutItemPicture.ResizeMode.Zoom` |
| `QgsUnitTypes.LayoutMillimeters` | `Qgis.LayoutUnit.Millimeters` |

Use a small helper based on `getattr(container, scope_name, None)` where a
supported older release lacks the scoped enum. Test the new scoped path first.
Qt6 moves `QAction` to `QtGui`; import it there with a Qt5 fallback when needed.

## Security and quality

- Run Python compilation, Bandit, detect-secrets and Flake8 locally.
- Treat hardcoded credentials, unsafe deserialization, shell injection, SQL
  injection and path traversal as real blockers.
- Do not use `shell=True`, `eval`, `exec`, `pickle`, or silent broad exceptions.
- Never expose API keys in exception text or request URLs.
- Validate archive members before extraction and resolve output paths safely.
- A documented inline suppression is acceptable only for a verified false
  positive; never use a blanket configuration to hide unknown findings.
- Scan the final vendored package. Remove dependency tests, examples, CLI tools,
  metadata directories and caches that are not needed at runtime.

## GitHub release

- Keep security and release workflows outside the plugin ZIP.
- Build the ZIP from the package directory so the internal root is correct.
- Validate ZIP integrity and assert the required internal paths.
- Pin vendored dependency versions and retain their licenses.
- Publish a clearly named asset such as `plugin_name-0.0.1.zip`.
- Recreate or replace the requested release only when the user authorized it.
- Verify workflow conclusions, release asset size/name and tag commit before
  reporting success.
