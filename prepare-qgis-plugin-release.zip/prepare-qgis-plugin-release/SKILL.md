---
name: prepare-qgis-plugin-release
description: Prepare existing QGIS Python plugins for official QGIS Plugins submission and GitHub releases. Use when asked to clean, harden, package, version, upload, or release a QGIS plugin; fix QGIS checker, Qt6/QGIS 4, metadata, Bandit, detect-secrets, Flake8, or ZIP-structure findings; or improve its README and changelog. Do not use for unrelated Python packages or ordinary QGIS usage help.
---

# Prepare a QGIS Plugin Release

Produce a minimal installable plugin ZIP whose source, metadata, documentation,
security scans, GitHub tag and release asset all describe the same version.

## Workflow

1. Resolve the source and target repository. Inspect any uploaded ZIP and the
   repository before editing. Respect an explicit version; when the user says
   “same as above,” carry forward the visible prior convention.
2. Work from a local copy and preserve unrelated repository content until its
   purpose is understood. For Hemed's repositories, use `Hemed Lungo`,
   `hemedlungo@gmail.com`, and the target GitHub repository for homepage,
   repository and tracker unless the user supplies different values.
3. Read [references/acceptance-checklist.md](references/acceptance-checklist.md)
   before changing compatibility, metadata, packaging or release automation.
4. Keep the plugin's behavior intact. Remove obsolete generated UI/resources,
   old embedded ZIPs, abandoned dialogs and build artifacts only after proving
   they are unused. Preserve required datasets, icons and third-party licenses.
5. Make QGIS 3.x/Qt5 and QGIS 4.x/Qt6 code paths explicit. Prefer scoped enums
   with narrow attribute-based fallbacks. Never import `PyQt5` directly; use
   `qgis.PyQt`.
6. Fix real security problems rather than suppressing them. Replace silent
   `except` blocks with specific handling or logging. For vendored dependencies,
   prune unused tests/CLI files, retain licenses, pin versions, and suppress only
   documented false positives that are demonstrably harmless.
7. Create a clear README with badges, installation and usage steps, compatibility,
   support, and licensing. Put one matching paragraph changelog in the README,
   `metadata.txt`, package changelog and release notes.
8. Build the exact installable ZIP and run:

   ```bash
   python scripts/audit_qgis_plugin.py PATH_TO_PLUGIN_OR_ZIP --version VERSION
   ```

   Also test functionality that does not require a QGIS runtime. If the plugin
   vendors dependencies, audit the final packaged tree, not only first-party code.
9. Add repository-owned security and release workflows when publishing is in
   scope. The release workflow must create a named asset, not rely on GitHub's
   automatic source archive.
10. Push only after local validation passes. Verify both workflows, the release
    asset name, ZIP contents, and that the release tag points to the corrected
    commit. Do not claim a live QGIS runtime test unless one was actually run.

## Packaging invariants

- Use one top-level directory that is a valid Python identifier, normally
  lowercase with underscores.
- Place `__init__.py` and `metadata.txt` directly inside that directory.
- Exclude repository workflows, caches, tests, build helpers, hidden files and
  old archives from the installable ZIP unless they are runtime requirements.
- Keep required code/data licenses inside the package; preserve separate
  third-party licensing where dependencies or datasets require it.
- Keep the requested version identical in metadata, filenames, README links,
  changelog, workflow, tag and release title.

## Completion report

Lead with the outcome. Link the repository, release, exact installable asset and
final commit. State which checks passed and any runtime verification limitation.
Do not call GitHub's “Source code (zip)” file installable.
