#!/usr/bin/env python3
"""Audit a QGIS plugin directory or installable ZIP before submission."""

from __future__ import annotations

import argparse
import ast
import configparser
import json
import os
from pathlib import Path
import re
import shutil
# Scanner names are fixed, paths are resolved, and no shell is used.
import subprocess  # nosec B404
import sys
import tempfile
from zipfile import BadZipFile, ZipFile


REQUIRED_METADATA = (
    "name",
    "description",
    "version",
    "qgisMinimumVersion",
    "author",
    "email",
    "repository",
    "tracker",
)

LEGACY_PATTERNS = {
    r"Qgis\.(Info|Warning|Critical|Success)\b": "Use Qgis.MessageLevel.*",
    (
        r"Qt\.(DisplayRole|DecorationRole|AlignCenter|NoPen|KeepAspectRatio|"
        r"FastTransformation|CaseInsensitive|MatchContains|"
        r"ShortcutFocusReason)\b"
    ): "Use the scoped Qt enum",
    r"QColor\.(HexArgb|HexRgb)\b": "Use QColor.NameFormat.*",
    r"QColorDialog\.ShowAlphaChannel\b": (
        "Use QColorDialog.ColorDialogOption.ShowAlphaChannel"
    ),
    r"QImage\.Format_[A-Za-z0-9_]+\b": "Use QImage.Format.*",
    r"QgsProcessing\.TypeVector[A-Za-z0-9_]+\b": "Use QgsProcessing.SourceType.*",
    r"QgsFeatureSink\.FastInsert\b": "Use QgsFeatureSink.Flag.FastInsert",
    r"QgsProcessingAlgorithm\.Flag[A-Za-z0-9_]+\b": (
        "Use Qgis.ProcessingAlgorithmFlag.*"
    ),
    r"QgsProcessingParameterNumber\.(Integer|Double)\b": (
        "Use Qgis.ProcessingNumberParameterType.*"
    ),
    r"QgsLayoutItemPicture\.Zoom\b": "Use QgsLayoutItemPicture.ResizeMode.Zoom",
    r"QgsUnitTypes\.LayoutMillimeters\b": "Use Qgis.LayoutUnit.Millimeters",
}


class Audit:
    def __init__(self):
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def error(self, message: str) -> None:
        self.errors.append(message)

    def warn(self, message: str) -> None:
        self.warnings.append(message)


def locate_package(path: Path, temporary: Path, audit: Audit) -> Path | None:
    if path.is_file():
        try:
            with ZipFile(path) as archive:
                bad_member = archive.testzip()
                if bad_member:
                    audit.error("Corrupt ZIP member: {}".format(bad_member))
                    return None
                names = [name for name in archive.namelist() if name.strip("/")]
                roots = {name.split("/", 1)[0] for name in names}
                if len(roots) != 1:
                    audit.error(
                        "ZIP must contain one top-level directory: {}".format(
                            sorted(roots)
                        )
                    )
                    return None
                temporary_root = temporary.resolve()
                for member in archive.infolist():
                    relative = Path(member.filename.replace("\\", "/"))
                    if relative.is_absolute() or ".." in relative.parts:
                        audit.error(
                            "Unsafe ZIP member path: {}".format(member.filename)
                        )
                        return None
                    destination = (temporary_root / relative).resolve()
                    if (
                        destination != temporary_root
                        and temporary_root not in destination.parents
                    ):
                        audit.error(
                            "ZIP member escapes extraction root: {}".format(
                                member.filename
                            )
                        )
                        return None
                    if member.is_dir():
                        destination.mkdir(parents=True, exist_ok=True)
                        continue
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(member) as source, destination.open(
                        "wb"
                    ) as target:
                        shutil.copyfileobj(source, target)
                package = temporary / next(iter(roots))
        except BadZipFile as error:
            audit.error("Invalid ZIP: {}".format(error))
            return None
    elif path.is_dir() and (path / "metadata.txt").is_file():
        package = path
    elif path.is_dir():
        candidates = [
            item
            for item in path.iterdir()
            if item.is_dir()
            and (item / "metadata.txt").is_file()
            and (item / "__init__.py").is_file()
        ]
        if len(candidates) != 1:
            audit.error("Could not identify exactly one plugin package directory.")
            return None
        package = candidates[0]
    else:
        audit.error("Path does not exist: {}".format(path))
        return None

    if not package.name.isidentifier():
        audit.error(
            "Top-level directory is not a valid Python identifier: {}".format(
                package.name
            )
        )
    if not (package / "__init__.py").is_file():
        audit.error("Missing {}/__init__.py".format(package.name))
    if not (package / "metadata.txt").is_file():
        audit.error("Missing {}/metadata.txt".format(package.name))
    return package


def check_metadata(package: Path, expected_version: str | None, audit: Audit) -> None:
    parser = configparser.ConfigParser()
    try:
        with (package / "metadata.txt").open(encoding="utf-8") as handle:
            parser.read_file(handle)
    except (OSError, configparser.Error) as error:
        audit.error("Cannot parse metadata.txt: {}".format(error))
        return
    if "general" not in parser:
        audit.error("metadata.txt has no [general] section.")
        return
    general = parser["general"]
    for key in REQUIRED_METADATA:
        if not general.get(key, "").strip():
            audit.error("Required metadata is missing or empty: {}".format(key))
    if expected_version and general.get("version") != expected_version:
        audit.error(
            "Metadata version {} does not match expected {}.".format(
                general.get("version", "<missing>"), expected_version
            )
        )


def check_python(package: Path, audit: Audit) -> None:
    for path in sorted(package.rglob("*.py")):
        if "vendor" in path.parts:
            continue
        relative = path.relative_to(package)
        try:
            source = path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(relative))
        except (OSError, UnicodeError, SyntaxError) as error:
            audit.error("{}: {}".format(relative, error))
            continue

        for pattern, guidance in LEGACY_PATTERNS.items():
            for match in re.finditer(pattern, source):
                line = source.count("\n", 0, match.start()) + 1
                audit.error("{}:{}: {}".format(relative, line, guidance))

        for node in ast.walk(tree):
            if not isinstance(node, ast.ExceptHandler):
                continue
            if len(node.body) == 1 and isinstance(
                node.body[0], (ast.Pass, ast.Continue)
            ):
                audit.error(
                    "{}:{}: silent exception handler uses {}.".format(
                        relative,
                        node.lineno,
                        node.body[0].__class__.__name__.lower(),
                    )
                )


def check_files(package: Path, audit: Audit) -> None:
    for path in package.rglob("*"):
        relative = path.relative_to(package)
        if any(part.startswith(".") for part in relative.parts):
            audit.warn("Hidden package path: {}".format(relative))
        if path.is_file() and os.access(path, os.X_OK):
            audit.warn("Executable package file: {}".format(relative))
        if path.name in {"__pycache__", ".DS_Store"} or path.suffix in {
            ".pyc",
            ".pyo",
        }:
            audit.error("Build/cache artifact included: {}".format(relative))


def run_scanners(package: Path, audit: Audit) -> None:
    scanner_args = (
        ("bandit", ["-r", str(package), "-q"]),
        (
            "flake8",
            [
                str(package),
                "--max-line-length=88",
                "--exclude=vendor",
            ],
        ),
    )
    for name, arguments in scanner_args:
        executable = shutil.which(name)
        if not executable:
            audit.warn("{} is not installed; scanner was skipped.".format(name))
            continue
        # The executable is resolved from a fixed scanner name.
        result = subprocess.run(  # nosec B603
            [executable] + arguments,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode:
            output = (result.stdout + result.stderr).strip()
            audit.error("{} reported findings:\n{}".format(name, output))

    executable = shutil.which("detect-secrets")
    if not executable:
        audit.warn("detect-secrets is not installed; scanner was skipped.")
        return
    # The executable is resolved from a fixed scanner name.
    result = subprocess.run(  # nosec B603
        [executable, "scan", str(package), "--all-files"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode:
        audit.error("detect-secrets failed:\n{}".format(result.stderr.strip()))
        return
    try:
        findings = json.loads(result.stdout).get("results", {})
    except json.JSONDecodeError as error:
        audit.error("Could not parse detect-secrets output: {}".format(error))
        return
    if findings:
        audit.error(
            "detect-secrets reported findings:\n{}".format(
                json.dumps(findings, indent=2)
            )
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "path",
        type=Path,
        help="Plugin directory, repository root, or ZIP",
    )
    parser.add_argument("--version", help="Expected plugin version")
    parser.add_argument(
        "--skip-scanners",
        action="store_true",
        help="Skip external scanners",
    )
    args = parser.parse_args()

    audit = Audit()
    with tempfile.TemporaryDirectory(prefix="qgis-plugin-audit-") as temp_name:
        package = locate_package(args.path.resolve(), Path(temp_name), audit)
        if package is not None and (package / "metadata.txt").is_file():
            check_metadata(package, args.version, audit)
            check_python(package, audit)
            check_files(package, audit)
            if not args.skip_scanners:
                run_scanners(package, audit)

    for warning in audit.warnings:
        print("WARNING: {}".format(warning))
    for error in audit.errors:
        print("ERROR: {}".format(error))
    if audit.errors:
        print(
            "FAILED: {} error(s), {} warning(s)".format(
                len(audit.errors), len(audit.warnings)
            )
        )
        return 1
    print("PASSED: 0 errors, {} warning(s)".format(len(audit.warnings)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
